/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Shield, 
  Activity, 
  Users, 
  MessageSquare, 
  AlertTriangle, 
  CheckCircle2, 
  Terminal, 
  Cpu, 
  Network, 
  Database,
  Search,
  Settings,
  RefreshCw,
  Power,
  Zap,
  Globe,
  Lock,
  Heart,
  UserPlus,
  MessageCircle,
  Share2,
  Trash2,
  Filter
} from "lucide-react";
import { generateServices, DOMAINS, LANGUAGES } from "./constants";

type ServiceStatus = "online" | "offline" | "flickering" | "rebooting";

interface Service {
  id: number;
  name: string;
  domain: string;
  language: string;
  status: ServiceStatus;
  latency: number;
  uptime: string;
  lastUpdate: number;
}

interface LogEntry {
  id: string;
  timestamp: string;
  service: string;
  message: string;
  type: "info" | "warn" | "error" | "success";
}

export default function App() {
  const [services, setServices] = useState<Service[]>([]);
  const [selectedServiceId, setSelectedServiceId] = useState<number | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [systemUptime, setSystemUptime] = useState(0);
  const [activeTab, setActiveTab] = useState<"grid" | "logs" | "actions" | "recommendations" | "profiles">("grid");
  const [isRecommending, setIsRecommending] = useState(false);
  const [recommendations, setRecommendations] = useState<{ 
    name: string, 
    score: number, 
    reason: string, 
    path: number,
    interests: string[],
    mutualFriends: number,
    language: string,
    domain: string
  }[]>([]);
  const [recFilterInterest, setRecFilterInterest] = useState("");
  const [recFilterMinMutual, setRecFilterMinMutual] = useState(0);
  const [recFilterLanguage, setRecFilterLanguage] = useState("ALL");
  const [recFilterDomain, setRecFilterDomain] = useState("ALL");
  const [selectedProfile, setSelectedProfile] = useState<any | null>(null);
  const [isFetchingProfile, setIsFetchingProfile] = useState(false);
  const [filterDomain, setFilterDomain] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  
  const filteredRecommendations = useMemo(() => {
    return recommendations.filter(rec => {
      const matchesInterest = recFilterInterest === "" || 
        rec.interests.some(i => i.toLowerCase().includes(recFilterInterest.toLowerCase()));
      const matchesMutual = rec.mutualFriends >= recFilterMinMutual;
      const matchesLanguage = recFilterLanguage === "ALL" || rec.language === recFilterLanguage;
      const matchesDomain = recFilterDomain === "ALL" || rec.domain === recFilterDomain;
      
      return matchesInterest && matchesMutual && matchesLanguage && matchesDomain;
    });
  }, [recommendations, recFilterInterest, recFilterMinMutual, recFilterLanguage, recFilterDomain]);

  const logEndRef = useRef<HTMLDivElement>(null);

  // Initialize services
  useEffect(() => {
    setServices(generateServices());
    const interval = setInterval(() => {
      setSystemUptime(prev => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const runRecommendationEngine = () => {
    setIsRecommending(true);
    setRecommendations([]);
    addLog("Friend-Rec-ML-Python", "Starting interest-based clustering...", "info");
    addLog("Friend-Rec-Graph-Go", "Initializing BFS traversal for mutual friends...", "info");

    setTimeout(() => {
      addLog("Friend-Rec-ML-Python", "Clustering complete. Identified 5 high-affinity clusters.", "success");
      addLog("Friend-Rec-Graph-Go", "Graph traversal complete. Found 12 candidate nodes within 3 hops.", "success");
      
      const mockRecs = [
        { 
          name: "Alice.iron", 
          score: 0.98, 
          reason: "Shared interest in 'Rust Memory Safety'", 
          path: 2,
          interests: ["Rust Memory Safety", "Distributed Consensus", "Kubernetes"],
          mutualFriends: 5,
          language: "Rust",
          domain: "Friendship Graph"
        },
        { 
          name: "Bob.iron", 
          score: 0.85, 
          reason: "4 mutual friends in 'Infrastructure' cluster", 
          path: 1,
          interests: ["Graph Theory", "Neo4j", "Infrastructure"],
          mutualFriends: 4,
          language: "Go",
          domain: "Infrastructure & Observability"
        },
        { 
          name: "Charlie.iron", 
          score: 0.72, 
          reason: "Frequent interaction with your 'Activity Feed'", 
          path: 3,
          interests: ["TensorFlow", "Python", "MLOps"],
          mutualFriends: 2,
          language: "Python",
          domain: "Activity Feed"
        },
        { 
          name: "Diana.iron", 
          score: 0.65, 
          reason: "ML predicted affinity based on 'Elixir' usage", 
          path: 2,
          interests: ["Elixir", "Phoenix", "Functional Programming"],
          mutualFriends: 1,
          language: "Elixir",
          domain: "Real-time Chat"
        },
        { 
          name: "Eve.iron", 
          score: 0.91, 
          reason: "High overlap in 'Rust' and 'Distributed' interests", 
          path: 2,
          interests: ["Rust", "Distributed Systems", "WebAssembly"],
          mutualFriends: 6,
          language: "Rust",
          domain: "Infrastructure & Observability"
        },
        { 
          name: "Frank.iron", 
          score: 0.55, 
          reason: "Common interest in 'Java' legacy systems", 
          path: 4,
          interests: ["Java", "Spring Boot", "Legacy Modernization"],
          mutualFriends: 0,
          language: "Java",
          domain: "User & Identity"
        },
      ];
      
      setRecommendations(mockRecs);
      setIsRecommending(false);
      addLog("SYSTEM", "Friend recommendations generated via Python/Go hybrid engine.", "success");
    }, 2000);
  };

  const fetchUserProfile = (userName: string) => {
    setIsFetchingProfile(true);
    setSelectedProfile(null);
    addLog("User-Profile-Java", `Fetching identity data for ${userName}...`, "info");
    addLog("Graph-Query-Rust", `Querying friendship graph for ${userName}...`, "info");
    addLog("Graph-Query-Rust", `Comparing friend lists to identify mutual connections...`, "info");
    addLog("Activity-Feed-Elixir", `Aggregating recent activity for ${userName}...`, "info");

    setTimeout(() => {
      const mockProfiles: Record<string, any> = {
        "Alice.iron": {
          name: "Alice.iron",
          role: "Senior Systems Architect",
          bio: "Specializing in distributed ironclad systems and polyglot microservices.",
          interests: ["Rust Memory Safety", "Distributed Consensus", "Kubernetes", "Haskell"],
          mutualFriends: ["Bob.iron", "Charlie.iron", "Diana.iron"],
          joined: "2024-01-15",
          location: "Ironclad-HQ-01",
          recentActivity: [
            { type: "post", content: "Just deployed a new mTLS layer across 400 nodes. Ironclad security is non-negotiable.", time: "2h ago" },
            { type: "like", content: "Liked Bob's post: 'Graph traversal optimization in Rust'", time: "5h ago" },
            { type: "comment", content: "Replied to Charlie: 'The ML model needs more training on edge cases.'", time: "1d ago" }
          ]
        },
        "Bob.iron": {
          name: "Bob.iron",
          role: "Graph Database Engineer",
          bio: "Building unbreakable relationship graphs with Neo4j and Rust.",
          interests: ["Graph Theory", "Neo4j", "Rust", "Infrastructure"],
          mutualFriends: ["Alice.iron", "Charlie.iron"],
          joined: "2024-02-20",
          location: "Ironclad-HQ-02",
          recentActivity: [
            { type: "post", content: "Graph traversal optimization in Rust is yielding 40% better throughput.", time: "1h ago" },
            { type: "like", content: "Liked Alice's post: 'Just deployed a new mTLS layer...'", time: "3h ago" },
            { type: "post", content: "New blog post: 'Why BFS is superior for friendship graphs'", time: "2d ago" }
          ]
        },
        "Charlie.iron": {
          name: "Charlie.iron",
          role: "ML Ops Specialist",
          bio: "Training ironclad models for predictive friendship affinity.",
          interests: ["TensorFlow", "Python", "MLOps", "Activity Feed"],
          mutualFriends: ["Alice.iron", "Bob.iron", "Diana.iron"],
          joined: "2024-03-10",
          location: "Ironclad-HQ-03",
          recentActivity: [
            { type: "post", content: "ML model v4.2 is now live. Affinity predictions are 15% more accurate.", time: "30m ago" },
            { type: "comment", content: "Replied to Alice: 'Agreed, working on the edge case dataset now.'", time: "12h ago" },
            { type: "like", content: "Liked Diana's post: 'Elixir concurrency is amazing.'", time: "1d ago" }
          ]
        }
      };

      setSelectedProfile(mockProfiles[userName] || mockProfiles["Alice.iron"]);
      setIsFetchingProfile(false);
      addLog("SYSTEM", `Profile for ${userName} fetched successfully.`, "success");
    }, 1500);
  };

  // Simulation Engine
  useEffect(() => {
    if (services.length === 0) return;

    const interval = setInterval(() => {
      setServices(current => {
        return current.map(s => {
          // 2% chance of a status change
          if (Math.random() < 0.02) {
            const nextStatus: ServiceStatus = 
              Math.random() > 0.95 ? "offline" : 
              Math.random() > 0.8 ? "flickering" : 
              Math.random() > 0.1 ? "online" : "rebooting";
            
            if (nextStatus !== s.status) {
              addLog(s.name, `Status changed to ${nextStatus}`, nextStatus === "online" ? "success" : nextStatus === "offline" ? "error" : "warn");
            }
            
            return { ...s, status: nextStatus, lastUpdate: Date.now() };
          }
          // Random latency jitter
          return { ...s, latency: Math.max(5, s.latency + (Math.random() * 10 - 5)) };
        });
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [services.length]);

  const addLog = (service: string, message: string, type: LogEntry["type"] = "info") => {
    const newLog: LogEntry = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toLocaleTimeString(),
      service,
      message,
      type,
    };
    setLogs(prev => [newLog, ...prev].slice(0, 100));
  };

  const filteredServices = useMemo(() => {
    return services.filter(s => {
      const matchesDomain = !filterDomain || s.domain === filterDomain;
      const matchesSearch = s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            s.language.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesDomain && matchesSearch;
    });
  }, [services, filterDomain, searchQuery]);

  const selectedService = useMemo(() => {
    return services.find(s => s.id === selectedServiceId);
  }, [services, selectedServiceId]);

  const stats = useMemo(() => {
    const online = services.filter(s => s.status === "online").length;
    const avgLatency = services.reduce((acc, s) => acc + s.latency, 0) / services.length;
    return { online, total: services.length, avgLatency: avgLatency.toFixed(1) };
  }, [services]);

  const formatUptime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleAction = (action: string) => {
    addLog("SYSTEM", `Executing action: ${action}...`, "info");
    setTimeout(() => {
      addLog("SYSTEM", `Action ${action} completed successfully via distributed consensus.`, "success");
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#E4E3E0] font-mono selection:bg-[#F27D26] selection:text-black overflow-hidden flex flex-col">
      {/* Header */}
      <header className="border-b border-[#141414] p-4 flex items-center justify-between bg-[#0a0a0a] z-20">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-[#F27D26] text-black rounded-sm">
            <Shield size={24} />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tighter uppercase italic">Ironclad Friends Managementiron</h1>
            <p className="text-[10px] opacity-50 uppercase tracking-widest">Polyglot Microservice Social Graph v1.0.1000</p>
          </div>
        </div>
        
        <div className="flex items-center gap-8 text-xs">
          <div className="flex flex-col items-end">
            <span className="text-[10px] opacity-40 uppercase">System Uptime</span>
            <span className="text-[#F27D26]">{formatUptime(systemUptime)}</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-[10px] opacity-40 uppercase">Nodes Online</span>
            <span className={stats.online < 950 ? "text-red-500" : "text-green-500"}>
              {stats.online}/{stats.total}
            </span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-[10px] opacity-40 uppercase">Avg Latency</span>
            <span>{stats.avgLatency}ms</span>
          </div>
        </div>
      </header>

      <main className="flex-1 flex overflow-hidden">
        {/* Sidebar - Service Details */}
        <aside className="w-80 border-r border-[#141414] bg-[#080808] flex flex-col z-10">
          <div className="p-4 border-b border-[#141414]">
            <div className="relative">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 opacity-30" size={14} />
              <input 
                type="text" 
                placeholder="SEARCH SERVICES..." 
                className="w-full bg-[#141414] border border-[#222] rounded-sm py-1.5 pl-8 pr-2 text-[11px] focus:outline-none focus:border-[#F27D26] transition-colors"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div className="mt-4 flex flex-wrap gap-1">
              <button 
                onClick={() => setFilterDomain(null)}
                className={`text-[9px] px-2 py-0.5 rounded-full border transition-colors ${!filterDomain ? 'bg-[#F27D26] text-black border-[#F27D26]' : 'border-[#222] opacity-50 hover:opacity-100'}`}
              >
                ALL
              </button>
              {DOMAINS.map(d => (
                <button 
                  key={d}
                  onClick={() => setFilterDomain(d)}
                  className={`text-[9px] px-2 py-0.5 rounded-full border transition-colors ${filterDomain === d ? 'bg-[#F27D26] text-black border-[#F27D26]' : 'border-[#222] opacity-50 hover:opacity-100'}`}
                >
                  {d.split(' ')[0]}
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
            <AnimatePresence mode="wait">
              {selectedService ? (
                <motion.div 
                  key={selectedService.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div className="space-y-1">
                    <h2 className="text-xl font-bold tracking-tight text-[#F27D26]">{selectedService.name}</h2>
                    <p className="text-[10px] opacity-50 uppercase tracking-widest">{selectedService.domain}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 bg-[#111] border border-[#222] rounded-sm">
                      <span className="block text-[9px] opacity-40 uppercase mb-1">Language</span>
                      <span className="text-sm font-bold">{selectedService.language}</span>
                    </div>
                    <div className="p-3 bg-[#111] border border-[#222] rounded-sm">
                      <span className="block text-[9px] opacity-40 uppercase mb-1">Status</span>
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${
                          selectedService.status === "online" ? "bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]" :
                          selectedService.status === "offline" ? "bg-red-500" :
                          "bg-yellow-500 animate-pulse"
                        }`} />
                        <span className="text-sm font-bold uppercase">{selectedService.status}</span>
                      </div>
                    </div>
                    <div className="p-3 bg-[#111] border border-[#222] rounded-sm">
                      <span className="block text-[9px] opacity-40 uppercase mb-1">Latency</span>
                      <span className="text-sm font-bold">{selectedService.latency.toFixed(1)}ms</span>
                    </div>
                    <div className="p-3 bg-[#111] border border-[#222] rounded-sm">
                      <span className="block text-[9px] opacity-40 uppercase mb-1">Uptime</span>
                      <span className="text-sm font-bold">{selectedService.uptime}%</span>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h3 className="text-[10px] opacity-40 uppercase tracking-widest font-bold border-b border-[#141414] pb-1">Capabilities</h3>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-[11px] opacity-70">
                        <Zap size={12} className="text-[#F27D26]" />
                        <span>High-availability clustering</span>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] opacity-70">
                        <Globe size={12} className="text-[#F27D26]" />
                        <span>Distributed consensus (Raft)</span>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] opacity-70">
                        <Lock size={12} className="text-[#F27D26]" />
                        <span>Ironclad mTLS encryption</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4">
                    <button 
                      onClick={() => handleAction(`REBOOT_${selectedService.name}`)}
                      className="w-full py-2 bg-[#141414] hover:bg-[#222] border border-[#333] text-[11px] font-bold uppercase tracking-widest transition-colors flex items-center justify-center gap-2"
                    >
                      <RefreshCw size={14} />
                      FORCE REBOOT
                    </button>
                  </div>
                </motion.div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center opacity-20 text-center space-y-4">
                  <Cpu size={48} />
                  <p className="text-[10px] uppercase tracking-[0.2em]">Select a service node to inspect its ironclad integrity</p>
                </div>
              )}
            </AnimatePresence>
          </div>
        </aside>

        {/* Main Content - Grid & Logs */}
        <section className="flex-1 flex flex-col bg-[#050505] relative">
          {/* Tabs */}
          <div className="flex border-b border-[#141414] bg-[#0a0a0a]">
            <button 
              onClick={() => setActiveTab("grid")}
              className={`px-6 py-3 text-[11px] font-bold uppercase tracking-widest transition-colors border-b-2 ${activeTab === "grid" ? "border-[#F27D26] text-[#F27D26]" : "border-transparent opacity-40 hover:opacity-100"}`}
            >
              SERVICE GRID
            </button>
            <button 
              onClick={() => setActiveTab("logs")}
              className={`px-6 py-3 text-[11px] font-bold uppercase tracking-widest transition-colors border-b-2 ${activeTab === "logs" ? "border-[#F27D26] text-[#F27D26]" : "border-transparent opacity-40 hover:opacity-100"}`}
            >
              SYSTEM LOGS
            </button>
            <button 
              onClick={() => setActiveTab("actions")}
              className={`px-6 py-3 text-[11px] font-bold uppercase tracking-widest transition-colors border-b-2 ${activeTab === "actions" ? "border-[#F27D26] text-[#F27D26]" : "border-transparent opacity-40 hover:opacity-100"}`}
            >
              IRON ACTIONS
            </button>
            <button 
              onClick={() => setActiveTab("recommendations")}
              className={`px-6 py-3 text-[11px] font-bold uppercase tracking-widest transition-colors border-b-2 ${activeTab === "recommendations" ? "border-[#F27D26] text-[#F27D26]" : "border-transparent opacity-40 hover:opacity-100"}`}
            >
              RECOMMENDATIONS
            </button>
            <button 
              onClick={() => setActiveTab("profiles")}
              className={`px-6 py-3 text-[11px] font-bold uppercase tracking-widest transition-colors border-b-2 ${activeTab === "profiles" ? "border-[#F27D26] text-[#F27D26]" : "border-transparent opacity-40 hover:opacity-100"}`}
            >
              USER PROFILES
            </button>
          </div>

          <div className="flex-1 overflow-hidden relative">
            {activeTab === "grid" && (
              <div className="h-full p-6 overflow-y-auto custom-scrollbar">
                <div className="grid grid-cols-[repeat(auto-fill,minmax(12px,1fr))] gap-1.5">
                  {filteredServices.map((s) => (
                    <motion.button
                      key={s.id}
                      layoutId={`service-${s.id}`}
                      onClick={() => setSelectedServiceId(s.id)}
                      className={`aspect-square rounded-[1px] transition-all duration-300 relative group ${
                        selectedServiceId === s.id ? 'ring-1 ring-[#F27D26] ring-offset-2 ring-offset-[#050505] scale-125 z-10' : ''
                      } ${
                        s.status === "online" ? "bg-green-500/40 hover:bg-green-500" :
                        s.status === "offline" ? "bg-red-500/40 hover:bg-red-500" :
                        "bg-yellow-500/40 hover:bg-yellow-500 animate-pulse"
                      }`}
                      title={`${s.name} (${s.language})`}
                    >
                      {selectedServiceId === s.id && (
                        <motion.div 
                          layoutId="active-glow"
                          className="absolute inset-0 bg-[#F27D26] blur-[4px] opacity-50"
                        />
                      )}
                    </motion.button>
                  ))}
                </div>
              </div>
            )}

            {activeTab === "logs" && (
              <div className="h-full bg-[#020202] p-4 overflow-y-auto custom-scrollbar font-mono text-[11px]">
                <div className="space-y-1">
                  {logs.map((log) => (
                    <div key={log.id} className="flex gap-4 group hover:bg-[#111] px-2 py-0.5 transition-colors">
                      <span className="opacity-30 whitespace-nowrap">[{log.timestamp}]</span>
                      <span className="text-[#F27D26] font-bold whitespace-nowrap w-24 overflow-hidden text-ellipsis">[{log.service}]</span>
                      <span className={`${
                        log.type === "error" ? "text-red-500" :
                        log.type === "warn" ? "text-yellow-500" :
                        log.type === "success" ? "text-green-500" :
                        "text-[#E4E3E0] opacity-80"
                      }`}>
                        {log.message}
                      </span>
                    </div>
                  ))}
                  <div ref={logEndRef} />
                </div>
              </div>
            )}

            {activeTab === "actions" && (
              <div className="h-full p-8 overflow-y-auto custom-scrollbar">
                <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
                  <ActionCard 
                    icon={<UserPlus size={24} />}
                    title="User Registration"
                    desc="Simulate a new user joining the ironclad network via Java/ACID service."
                    onClick={() => handleAction("USER_REGISTRATION")}
                  />
                  <ActionCard 
                    icon={<Heart size={24} />}
                    title="Friend Request"
                    desc="Initiate a friendship link through the Kotlin/Graph service."
                    onClick={() => handleAction("FRIEND_REQUEST")}
                  />
                  <ActionCard 
                    icon={<MessageCircle size={24} />}
                    title="Broadcast Message"
                    desc="Send a real-time message across the Elixir/Phoenix cluster."
                    onClick={() => handleAction("BROADCAST_MESSAGE")}
                  />
                  <ActionCard 
                    icon={<Share2 size={24} />}
                    title="Feed Aggregation"
                    desc="Rebuild activity feeds using the Rust/Low-Latency fan-out engine."
                    onClick={() => handleAction("FEED_REBUILD")}
                  />
                  <ActionCard 
                    icon={<Shield size={24} />}
                    title="Security Audit"
                    desc="Run a system-wide vulnerability scan across all 1000 runtimes."
                    onClick={() => handleAction("SECURITY_AUDIT")}
                  />
                  <ActionCard 
                    icon={<Trash2 size={24} />}
                    title="Purge Inactive"
                    desc="Clean up stale friendship links using Clojure/Immutable processing."
                    onClick={() => handleAction("PURGE_INACTIVE")}
                  />
                </div>
              </div>
            )}

            {activeTab === "recommendations" && (
              <div className="h-full p-8 overflow-y-auto custom-scrollbar">
                <div className="max-w-4xl mx-auto space-y-8">
                  <div className="flex items-center justify-between border-b border-[#141414] pb-6">
                    <div>
                      <h2 className="text-2xl font-bold tracking-tighter text-[#F27D26] uppercase italic">Dynamic Recommendation Engine</h2>
                      <p className="text-[11px] opacity-50 uppercase tracking-widest mt-1">Hybrid Python (ML) + Go (Graph) Architecture</p>
                    </div>
                    <button 
                      onClick={runRecommendationEngine}
                      disabled={isRecommending}
                      className={`px-6 py-3 bg-[#F27D26] text-black text-[11px] font-bold uppercase tracking-widest hover:bg-[#ff8c3a] transition-all flex items-center gap-2 ${isRecommending ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      {isRecommending ? <RefreshCw className="animate-spin" size={14} /> : <Zap size={14} />}
                      {isRecommending ? "ANALYZING GRAPH..." : "GENERATE RECOMMENDATIONS"}
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="p-6 bg-[#0a0a0a] border border-[#141414] space-y-4">
                      <div className="flex items-center gap-3 text-[#F27D26]">
                        <Cpu size={20} />
                        <h3 className="text-sm font-bold uppercase tracking-widest">Python ML Service</h3>
                      </div>
                      <p className="text-[11px] opacity-60 leading-relaxed">
                        Utilizes interest-based clustering and collaborative filtering to predict user affinity scores.
                      </p>
                      <div className="flex items-center justify-between text-[10px] opacity-40 font-bold">
                        <span>MODEL: TENSORFLOW/SCIKIT-LEARN</span>
                        <span>LATENCY: 45MS</span>
                      </div>
                    </div>
                    <div className="p-6 bg-[#0a0a0a] border border-[#141414] space-y-4">
                      <div className="flex items-center gap-3 text-[#F27D26]">
                        <Network size={20} />
                        <h3 className="text-sm font-bold uppercase tracking-widest">Go Graph Service</h3>
                      </div>
                      <p className="text-[11px] opacity-60 leading-relaxed">
                        Executes high-performance BFS/DFS traversals to find mutual friends and calculate path distances.
                      </p>
                      <div className="flex items-center justify-between text-[10px] opacity-40 font-bold">
                        <span>ALGO: DIJKSTRA/BFS</span>
                        <span>LATENCY: 12MS</span>
                      </div>
                    </div>
                  </div>

                  {/* Filters */}
                  <div className="p-6 bg-[#0a0a0a] border border-[#141414] space-y-6">
                    <div className="flex items-center gap-2 text-[#F27D26]">
                      <Filter size={16} />
                      <h3 className="text-[10px] font-bold uppercase tracking-widest">Filter Recommendations</h3>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="space-y-2">
                        <label className="text-[9px] opacity-40 uppercase font-bold">Interest Search</label>
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 -translate-y-1/2 opacity-30" size={12} />
                          <input 
                            type="text"
                            value={recFilterInterest}
                            onChange={(e) => setRecFilterInterest(e.target.value)}
                            placeholder="e.g. Rust"
                            className="w-full bg-[#141414] border border-[#222] px-8 py-2 text-[11px] focus:outline-none focus:border-[#F27D26]"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[9px] opacity-40 uppercase font-bold">Min Mutual Friends</label>
                        <input 
                          type="number"
                          min="0"
                          value={recFilterMinMutual}
                          onChange={(e) => setRecFilterMinMutual(parseInt(e.target.value) || 0)}
                          className="w-full bg-[#141414] border border-[#222] px-3 py-2 text-[11px] focus:outline-none focus:border-[#F27D26]"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-[9px] opacity-40 uppercase font-bold">Language</label>
                        <select 
                          value={recFilterLanguage}
                          onChange={(e) => setRecFilterLanguage(e.target.value)}
                          className="w-full bg-[#141414] border border-[#222] px-3 py-2 text-[11px] focus:outline-none focus:border-[#F27D26] appearance-none"
                        >
                          <option value="ALL">ALL LANGUAGES</option>
                          {LANGUAGES.map(lang => (
                            <option key={lang} value={lang}>{lang.toUpperCase()}</option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[9px] opacity-40 uppercase font-bold">Domain</label>
                        <select 
                          value={recFilterDomain}
                          onChange={(e) => setRecFilterDomain(e.target.value)}
                          className="w-full bg-[#141414] border border-[#222] px-3 py-2 text-[11px] focus:outline-none focus:border-[#F27D26] appearance-none"
                        >
                          <option value="ALL">ALL DOMAINS</option>
                          {DOMAINS.map(domain => (
                            <option key={domain} value={domain}>{domain.toUpperCase()}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-[10px] opacity-40 uppercase tracking-widest font-bold border-b border-[#141414] pb-1">
                      Recommended Connections ({filteredRecommendations.length})
                    </h3>
                    <AnimatePresence>
                      {filteredRecommendations.length > 0 ? (
                        <div className="grid grid-cols-1 gap-3">
                          {filteredRecommendations.map((rec, idx) => (
                            <motion.div 
                              key={rec.name}
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: idx * 0.1 }}
                              className="p-4 bg-[#111] border border-[#222] flex items-center justify-between group hover:border-[#F27D26] transition-colors"
                            >
                              <div className="flex items-center gap-4">
                                <div className="w-10 h-10 bg-[#141414] border border-[#222] flex items-center justify-center text-[#F27D26]">
                                  <Users size={20} />
                                </div>
                                <div>
                                  <h4 className="text-sm font-bold">{rec.name}</h4>
                                  <p className="text-[10px] opacity-50">{rec.reason}</p>
                                  <div className="flex gap-2 mt-1">
                                    <span className="text-[8px] px-1 bg-[#222] text-[#F27D26] font-bold">{rec.language}</span>
                                    <span className="text-[8px] px-1 bg-[#222] opacity-60 font-bold">{rec.domain}</span>
                                  </div>
                                </div>
                              </div>
                              <div className="flex items-center gap-8 text-right">
                                <div>
                                  <span className="block text-[9px] opacity-40 uppercase">Affinity</span>
                                  <span className="text-xs font-bold text-green-500">{(rec.score * 100).toFixed(0)}%</span>
                                </div>
                                <div>
                                  <span className="block text-[9px] opacity-40 uppercase">Mutual</span>
                                  <span className="text-xs font-bold">{rec.mutualFriends}</span>
                                </div>
                                <div>
                                  <span className="block text-[9px] opacity-40 uppercase">Path</span>
                                  <span className="text-xs font-bold">{rec.path} HOPS</span>
                                </div>
                                <button className="p-2 bg-[#141414] hover:bg-[#F27D26] hover:text-black transition-colors">
                                  <UserPlus size={14} />
                                </button>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      ) : !isRecommending && (
                        <div className="h-40 flex flex-col items-center justify-center opacity-20 text-center space-y-2">
                          <Activity size={32} />
                          <p className="text-[10px] uppercase tracking-widest">
                            {recommendations.length > 0 ? "No recommendations match your filters" : "No recommendations generated yet"}
                          </p>
                        </div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "profiles" && (
              <div className="h-full p-8 overflow-y-auto custom-scrollbar">
                <div className="max-w-4xl mx-auto space-y-8">
                  <div className="flex items-center justify-between border-b border-[#141414] pb-6">
                    <div>
                      <h2 className="text-2xl font-bold tracking-tighter text-[#F27D26] uppercase italic">Ironclad User Profiles</h2>
                      <p className="text-[11px] opacity-50 uppercase tracking-widest mt-1">Identity (Java) + Graph (Rust) Integration</p>
                    </div>
                    <div className="flex gap-2">
                      {["Alice.iron", "Bob.iron", "Charlie.iron"].map(name => (
                        <button 
                          key={name}
                          onClick={() => fetchUserProfile(name)}
                          disabled={isFetchingProfile}
                          className={`px-4 py-2 border border-[#222] text-[10px] font-bold uppercase tracking-widest hover:border-[#F27D26] transition-all ${selectedProfile?.name === name ? 'bg-[#F27D26] text-black border-[#F27D26]' : 'bg-[#0a0a0a] opacity-60 hover:opacity-100'}`}
                        >
                          {name}
                        </button>
                      ))}
                    </div>
                  </div>

                  <AnimatePresence mode="wait">
                    {isFetchingProfile ? (
                      <motion.div 
                        key="loading"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="h-64 flex flex-col items-center justify-center space-y-4"
                      >
                        <RefreshCw className="animate-spin text-[#F27D26]" size={32} />
                        <p className="text-[10px] uppercase tracking-widest opacity-40">Querying identity & graph nodes...</p>
                      </motion.div>
                    ) : selectedProfile ? (
                      <motion.div 
                        key={selectedProfile.name}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="grid grid-cols-1 md:grid-cols-3 gap-8"
                      >
                        {/* Profile Info */}
                        <div className="md:col-span-1 space-y-6">
                          <div className="p-6 bg-[#0a0a0a] border border-[#141414] text-center space-y-4">
                            <div className="w-24 h-24 mx-auto bg-[#141414] border border-[#222] flex items-center justify-center text-[#F27D26] rounded-sm">
                              <Users size={48} />
                            </div>
                            <div>
                              <h3 className="text-lg font-bold text-[#F27D26]">{selectedProfile.name}</h3>
                              <p className="text-[10px] opacity-50 uppercase">{selectedProfile.role}</p>
                            </div>
                            <div className="pt-4 border-t border-[#141414] text-left space-y-2">
                              <div className="flex justify-between text-[10px]">
                                <span className="opacity-40">MUTUAL FRIENDS</span>
                                <span className="text-[#F27D26] font-bold">{selectedProfile.mutualFriends.length}</span>
                              </div>
                              <div className="flex justify-between text-[10px]">
                                <span className="opacity-40">JOINED</span>
                                <span>{selectedProfile.joined}</span>
                              </div>
                              <div className="flex justify-between text-[10px]">
                                <span className="opacity-40">LOCATION</span>
                                <span>{selectedProfile.location}</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Details */}
                        <div className="md:col-span-2 space-y-8">
                          <div className="space-y-4">
                            <h3 className="text-[10px] opacity-40 uppercase tracking-widest font-bold border-b border-[#141414] pb-1">Biography</h3>
                            <p className="text-sm opacity-80 leading-relaxed">{selectedProfile.bio}</p>
                          </div>

                          <div className="grid grid-cols-2 gap-8">
                            <div className="space-y-4">
                              <h3 className="text-[10px] opacity-40 uppercase tracking-widest font-bold border-b border-[#141414] pb-1">Shared Interests</h3>
                              <div className="flex flex-wrap gap-2">
                                {selectedProfile.interests.map((interest: string) => (
                                  <span key={interest} className="px-2 py-1 bg-[#141414] border border-[#222] text-[9px] font-bold uppercase tracking-widest text-[#F27D26]">
                                    {interest}
                                  </span>
                                ))}
                              </div>
                            </div>

                            <div className="space-y-4">
                              <h3 className="text-[10px] opacity-40 uppercase tracking-widest font-bold border-b border-[#141414] pb-1">Common Connections</h3>
                              <div className="space-y-2">
                                {selectedProfile.mutualFriends.map((friend: string) => (
                                  <div key={friend} className="flex items-center gap-2 text-[11px] opacity-70">
                                    <div className="w-1.5 h-1.5 rounded-full bg-[#F27D26]" />
                                    <span>{friend}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>

                          <div className="pt-6 flex gap-3">
                            <button className="flex-1 py-3 bg-[#141414] hover:bg-[#222] border border-[#333] text-[11px] font-bold uppercase tracking-widest transition-colors flex items-center justify-center gap-2">
                              <MessageSquare size={14} />
                              SEND MESSAGE
                            </button>
                            <button className="flex-1 py-3 bg-[#141414] hover:bg-[#222] border border-[#333] text-[11px] font-bold uppercase tracking-widest transition-colors flex items-center justify-center gap-2">
                              <UserPlus size={14} />
                              ADD FRIEND
                            </button>
                          </div>

                          {/* Mini Activity Feed */}
                          <div className="space-y-4 pt-6 border-t border-[#141414]">
                            <div className="flex items-center gap-2">
                              <Activity size={14} className="text-[#F27D26]" />
                              <h3 className="text-[10px] opacity-40 uppercase tracking-widest font-bold">Recent Activity Feed</h3>
                            </div>
                            <div className="space-y-3">
                              {selectedProfile.recentActivity.map((activity: any, idx: number) => (
                                <div key={idx} className="p-3 bg-[#0a0a0a] border border-[#141414] flex gap-3 items-start group hover:border-[#F27D26] transition-colors">
                                  <div className="mt-1">
                                    {activity.type === 'post' && <Share2 size={12} className="text-blue-400" />}
                                    {activity.type === 'like' && <Heart size={12} className="text-red-400" />}
                                    {activity.type === 'comment' && <MessageCircle size={12} className="text-green-400" />}
                                  </div>
                                  <div className="flex-1">
                                    <p className="text-[11px] opacity-80 leading-relaxed">{activity.content}</p>
                                    <span className="text-[9px] opacity-30 uppercase font-bold">{activity.time}</span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ) : (
                      <div className="h-64 flex flex-col items-center justify-center opacity-20 text-center space-y-4">
                        <Users size={48} />
                        <p className="text-[10px] uppercase tracking-widest">Select a user profile to inspect ironclad identity data</p>
                      </div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Status Bar */}
          <footer className="h-10 border-t border-[#141414] bg-[#0a0a0a] flex items-center px-4 justify-between text-[10px] uppercase tracking-widest">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                <span className="opacity-60">System Healthy</span>
              </div>
              <div className="flex items-center gap-2">
                <Network size={12} className="opacity-40" />
                <span className="opacity-60">Mesh: Istio/mTLS Active</span>
              </div>
              <div className="flex items-center gap-2">
                <Database size={12} className="opacity-40" />
                <span className="opacity-60">Persistence: Polyglot/Saga</span>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="opacity-40 italic">"Job security through unmaintainable complexity"</span>
              <div className="flex items-center gap-2 border-l border-[#222] pl-4">
                <Terminal size={12} className="opacity-40" />
                <span>root@ironclad-mgmt:~#</span>
              </div>
            </div>
          </footer>
        </section>
      </main>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #141414;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #222;
        }
      `}</style>
    </div>
  );
}

function ActionCard({ icon, title, desc, onClick }: { icon: React.ReactNode, title: string, desc: string, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className="p-6 bg-[#0a0a0a] border border-[#141414] hover:border-[#F27D26] text-left transition-all group relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 p-2 opacity-5 group-hover:opacity-10 transition-opacity">
        {icon}
      </div>
      <div className="text-[#F27D26] mb-4 group-hover:scale-110 transition-transform origin-left">
        {icon}
      </div>
      <h3 className="text-sm font-bold uppercase tracking-widest mb-2">{title}</h3>
      <p className="text-[11px] opacity-50 leading-relaxed">{desc}</p>
      <div className="mt-4 flex items-center gap-2 text-[9px] font-bold text-[#F27D26] opacity-0 group-hover:opacity-100 transition-opacity">
        <span>EXECUTE COMMAND</span>
        <Zap size={10} />
      </div>
    </button>
  );
}
