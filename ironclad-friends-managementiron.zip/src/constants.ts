export const DOMAINS = [
  "User & Identity",
  "Friendship Graph",
  "Activity Feed",
  "Real-time Chat",
  "Moderation & Safety",
  "Infrastructure & Observability",
];

export const LANGUAGES = [
  "Java", "Rust", "C", "Node.js", "Elixir", "Python", "Clojure", "Kotlin", "Scala", "Ruby",
  "C++", "Haskell", "R", "Go", "C#", "PHP", "Erlang", "TensorFlow", "Zig", "Nim",
  "Groovy", "Perl", "TypeScript", "Dart", "Swift", "Julia", "Lua", "Crystal", "F#", "OCaml",
  "Brainfuck", "COBOL", "Fortran", "Lisp", "Prolog", "Smalltalk", "Ada", "D", "V", "HolyC",
  "Assembly", "Bash", "SQL", "GraphQL", "Solidity", "Vyper", "Move", "Cadence", "Ballerina", "Grain",
  "Koka", "Unison", "Idris", "Agda", "Lean", "Coq", "TLA+", "Alloy", "Z3", "SMT-LIB",
  "Verilog", "VHDL", "SystemVerilog", "Chisel", "SpinalHDL", "Bluespec", "Migen", "Amaranth", "Silq", "Q#",
  "Cirq", "Qiskit", "OpenQASM", "BQN", "APL", "J", "K", "Q", "Forth", "Factor",
  "PostScript", "Tcl", "Racket", "Scheme", "Common Lisp", "Emacs Lisp", "ClojureScript", "PureScript", "Elm", "Rescript",
  "Reason", "Flow", "ActionScript", "ColdFusion", "Delphi", "Pascal", "Modula-2", "Oberon", "Component Pascal", "BlackBox",
];

// Generate 1000 services
export const generateServices = () => {
  const services = [];
  
  // Ensure specific services for the recommendation engine
  services.push({
    id: 1001,
    name: "Friend-Rec-ML-Python",
    domain: "Friendship Graph",
    language: "Python",
    status: "online",
    latency: 45,
    uptime: "99.98",
  });
  
  services.push({
    id: 1002,
    name: "Friend-Rec-Graph-Go",
    domain: "Friendship Graph",
    language: "Go",
    status: "online",
    latency: 12,
    uptime: "99.99",
  });

  services.push({
    id: 1003,
    name: "User-Profile-Java",
    domain: "User & Identity",
    language: "Java",
    status: "online",
    latency: 30,
    uptime: "99.95",
  });

  services.push({
    id: 1004,
    name: "Graph-Query-Rust",
    domain: "Friendship Graph",
    language: "Rust",
    status: "online",
    latency: 8,
    uptime: "99.99",
  });

  for (let i = 0; i < 996; i++) {
    const domain = DOMAINS[Math.floor(Math.random() * DOMAINS.length)];
    const lang = LANGUAGES[Math.floor(Math.random() * LANGUAGES.length)];
    services.push({
      id: i,
      name: `${domain.split(' ')[0]}-Svc-${i.toString().padStart(4, '0')}`,
      domain,
      language: lang,
      status: Math.random() > 0.05 ? "online" : "flickering",
      latency: Math.floor(Math.random() * 200) + 10,
      uptime: (Math.random() * 99 + 1).toFixed(2),
    });
  }
  return services;
};
